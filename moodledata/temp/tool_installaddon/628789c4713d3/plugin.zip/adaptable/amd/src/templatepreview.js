/* jshint ignore:start */
define(['jquery', 'core/log'], function($, log) {

    "use strict"; // jshint ;_;

    log.debug('Adaptable Template Preview AMD');

    return {
        init: function() {
            $(document).ready(function() {
                log.debug('Adaptable Template Preview AMD init');
            });
        }
    };
});
/* jshint ignore:end */
